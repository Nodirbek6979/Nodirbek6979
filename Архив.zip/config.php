<?php

$config = [
    'TOKEN'=>"",
    'ADMINNAME'=>"",
    "DataBase"=>[
        'host'=>'hostname',
        'user'=>'username',
        'password'=>'password',
        'dbname'=>'databasename',
    ],
];
